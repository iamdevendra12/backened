package com.app.dao;





import java.util.List;

import javax.persistence.EntityManager;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.app.pojos.Address;
import com.app.pojos.ServiceProvider;
import com.app.pojos.ServiceProviderHelper;
import com.app.pojos.Services;
import com.app.pojos.User;
import com.app.pojos.UserRole;


@Repository
@Transactional
public class SpDaoImpl implements ISpDao 
{
	@Autowired
	private EntityManager sf;
		@Override
		public List<User> listofsp() {
			String jpql = "select sp from User sp where sp.role=:rl";
			return sf.unwrap(Session.class).createQuery(jpql, User.class).setParameter("rl", UserRole.SERVICEPROVIDER).getResultList();
		}
		
		@Override
		public List<ServiceProvider> listofavailablesp(int serviceId) {
			String jpql="select sp from ServiceProvider sp  join fetch sp.service where sp.status=:st and sp.service.serviceId=:id";
			
			return sf.unwrap(Session.class).createQuery(jpql, ServiceProvider.class).setParameter("st","available").setParameter("id",serviceId).getResultList();
			
		}
		@Override
		public ServiceProviderHelper registerSp(ServiceProviderHelper s) 
		{
			String jpql = "select s from Services s where s.serviceName=:name";
			User user = new User(s.getUserName(), s.getEmail(), s.getPassword(), s.getRole());
			Address address = new Address(s.getFlatNo(), s.getPinCode(), s.getHouseName(), s.getApartmentName(), s.getArea(), s.getCity(), s.getState(), s.getCountry(), s.getCellNo());
			//Services services=new Services();
			String serviceName = s.getService();
			double amount = 0;
			if(serviceName.equals("Electrician"))
			{
				amount=100;
			}
			else if(serviceName.equals("Plumber"))
				amount = 150;
			Services service = sf.unwrap(Session.class).createQuery(jpql,Services.class).setParameter("name", serviceName).getSingleResult();
			ServiceProvider sp=new ServiceProvider(amount, "available");
			user.addAddress(address);
			user.addSp(sp);
			service.addServiceProvider(sp);
			System.out.println(sp);
			sf.unwrap(Session.class).persist(sp);
			sf.unwrap(Session.class).persist(user);
			return s;
		}
		@Override
		public Address updateAddress(Address a, int addressId) {
		Address ad=sf.unwrap(Session.class).get(Address.class, addressId);
		ad.setFlatNo(a.getFlatNo());
		ad.setHouseName(a.getHouseName());
		ad.setApartmentName(a.getApartmentName());
		ad.setArea(a.getArea());
		ad.setCity(a.getCity());
		ad.setCountry(a.getCountry());
		ad.setPinCode(a.getPinCode());
		ad.setCellNo(a.getCellNo());
		sf.unwrap(Session.class).update(ad);
			return ad;
		}
		
		@Override
		public void deletesp(int serviceProviderId) 
		{
	  ServiceProvider u=sf.unwrap(Session.class).get(ServiceProvider.class, serviceProviderId);	
	  System.out.println("u"+u);
		if(u !=null)	
		 sf.unwrap(Session.class).remove(u);		
			
		}
		@Override
		public ServiceProvider getspById(int spId) {
			
			return sf.unwrap(Session.class).get(ServiceProvider.class, spId);
		}
		@Override
		public ServiceProvider getserviceProvider(int serviceProviderId) {
	String jpql="select sp from ServiceProvider sp  join fetch sp.service where sp.serviceProviderId=:st";
			
			return sf.unwrap(Session.class).createQuery(jpql, ServiceProvider.class).setParameter("st",serviceProviderId).getSingleResult();
		}
//		@Override
//		public ServiceProvider updateSpstatus(ServiceProvider s,int serviceProviderId) {
//			ServiceProvider sp=sf.unwrap(Session.class).get(ServiceProvider.class,serviceProviderId);
//			sp.setStatus("unavailable");
//			 sf.unwrap(Session.class).update(sp);
//			 return sp;
//		}
//		
		
		
		@Override
		public ServiceProvider updateSpstatusavailable(ServiceProvider s,int serviceProviderId) {
			ServiceProvider sp=sf.unwrap(Session.class).get(ServiceProvider.class,serviceProviderId);
			sp.setStatus("available");
			 sf.unwrap(Session.class).update(sp);
			 return sp;
		}
		
		
		@Override
		public ServiceProvider getStatus(int serviceProviderId) {
			//String jpql="select s.status from ServiceProvider s where s.serviceProviderId=:id ";
			//return sf.unwrap(Session.class).createNamedQuery(jpql, ServiceProvider.class).setParameter("id", serviceProviderId).getSingleResult();
			ServiceProvider sp=sf.unwrap(Session.class).get(ServiceProvider.class,serviceProviderId);
			sp.getStatus();
			sf.unwrap(Session.class).get(ServiceProvider.class,serviceProviderId);
			return sp;
			
		}

		@Override
		public List<ServiceProvider> allsp() {
			String jpql="select sp from ServiceProvider sp";
			return sf.unwrap(Session.class).createQuery(jpql, ServiceProvider.class).getResultList();
		}

		@Override
		public ServiceProvider updateSpstatus(ServiceProvider sp) 
		{
			if(sp.getStatus().equals("unavailable"))
				sp.setStatus("available");
			else
				sp.setStatus("unavailable");
			sf.unwrap(Session.class).update(sp);
			return sp;
		}

		@Override
		public ServiceProvider getSpByUser(User user) 
		{
			String jp = "select s from ServiceProvider s where s.user =:user ";
			return sf.unwrap(Session.class).createQuery(jp, ServiceProvider.class).setParameter("user", user).getSingleResult();
		}

		@Override
		public void changeStatus(ServiceProvider sp) 
		{
			sp.setStatus("unavailable");
			sf.unwrap(Session.class).update(sp);
		}

	

}
