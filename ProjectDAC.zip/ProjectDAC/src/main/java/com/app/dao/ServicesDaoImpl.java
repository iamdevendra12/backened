package com.app.dao;

import java.util.List;

import javax.persistence.EntityManager;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.app.pojos.Services;
@Repository
@Transactional
public class ServicesDaoImpl implements IservicesDao {
@Autowired
private EntityManager sf;
	@Override
	public List<Services> listOfServices() {
	String jpql="select s from Services s ";
		return sf.unwrap(Session.class).createQuery(jpql, Services.class).getResultList();
	}
	@Override
	public Services selectservice(int serviceId) {
		//String jpql="select s from Services s where s.serviceId=:id";
		//return sf.unwrap(Session.class)).createQuery(jpql, Services.class).setParameter("id", "serviceId").getSingleResult();
	     return sf.unwrap(Session.class).get(Services.class,serviceId);
	}

}
