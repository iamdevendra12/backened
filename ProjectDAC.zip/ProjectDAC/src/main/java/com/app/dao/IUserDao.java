package com.app.dao;

import com.app.pojos.User;

public interface IUserDao {
	User validateUser(String email,String password);
	User getUserById(int userId);
	void deleteUser(int userId);
	User getUserByEmail(String email);

}
