package com.app.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.dao.IservicesDao;
import com.app.pojos.Services;


@RestController
@CrossOrigin
@RequestMapping("/services")
public class ServicesController 
{
	@Autowired
	private IservicesDao dao;
	@GetMapping("/list")
	public ResponseEntity<?> listServices() {
		System.out.println("in list services");
		List<Services> allservices = dao.listOfServices();
		if (allservices.size() == 0)
			return new ResponseEntity<Void>(HttpStatus.NO_CONTENT);
		return new ResponseEntity<List<Services>>(allservices, HttpStatus.OK);
	}
	@GetMapping("/{serviceId}")
	public ResponseEntity<?>selectService(@PathVariable int serviceId)
	{
		System.out.println("in selected service");
		Services s=dao.selectservice(serviceId);
		if(s==null)
			return new ResponseEntity<Void>(HttpStatus.NO_CONTENT);
		return new ResponseEntity<Services>(s, HttpStatus.OK);

	}

}
