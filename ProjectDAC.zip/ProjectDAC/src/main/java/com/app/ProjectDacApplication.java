package com.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjectDacApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjectDacApplication.class, args);
	}

}
