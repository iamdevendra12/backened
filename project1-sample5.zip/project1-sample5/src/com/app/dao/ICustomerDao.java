package com.app.dao;

import com.app.pojos.Address;
import com.app.pojos.Orders;
import com.app.pojos.ServiceProvider;
import com.app.pojos.User;
import com.app.pojos.UserHelper;

public interface ICustomerDao {
	UserHelper registerNewMember(UserHelper u); 
	//Address updateAddress(Address a,int userId);
	//User updateMember(User u);
	User updateUser(UserHelper u, int userId);
	Address updateAddress(Address a,int addressId);
	//User getUser(int userId);
	User getUserByEmail(String userEmail);
	ServiceProvider getSPById(int spId);
	String addOrder(User user, Orders o, ServiceProvider sp);

}
