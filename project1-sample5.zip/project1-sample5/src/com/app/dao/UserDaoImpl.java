package com.app.dao;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.app.pojos.User;
@Repository
@Transactional
public class UserDaoImpl implements IUserDao {
@Autowired
private SessionFactory sf;
	@Override
	public User validateUser(String email, String password) {
		String jpql = "select u from User u where u.email=:em and u.password=:pass";
		return sf.getCurrentSession().createQuery(jpql, User.class).setParameter("em", email)
				.setParameter("pass", password).getSingleResult();
	}
	@Override
	public void deleteUser(int userId) 
	{
		User id=sf.getCurrentSession().get(User.class, userId);
		
	if(id !=null)	
	 sf.getCurrentSession().delete(id);	
		
	}
	@Override
	public User getUserById(int userId) {
		
		return sf.getCurrentSession().get(User.class, userId);
	}
	@Override
	public User getUserByEmail(String email) 
	{
		String jpql = "select u from User u where u.email=:em";
		return sf.getCurrentSession().createQuery(jpql, User.class).setParameter("em", email).getSingleResult();
	}

}
