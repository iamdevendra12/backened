package com.app.dao;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.app.pojos.Services;
import com.google.protobuf.Service;
@Repository
@Transactional
public class ServicesDaoImpl implements IservicesDao {
@Autowired
private SessionFactory sf;
	@Override
	public List<Services> listOfServices() {
	String jpql="select s from Services s ";
		return sf.getCurrentSession().createQuery(jpql, Services.class).getResultList();
	}
	@Override
	public Services selectservice(int serviceId) {
		//String jpql="select s from Services s where s.serviceId=:id";
		//return sf.getCurrentSession().createQuery(jpql, Services.class).setParameter("id", "serviceId").getSingleResult();
	     return sf.getCurrentSession().get(Services.class,serviceId);
	}

}
