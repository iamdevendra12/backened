package com.app.dao;

import java.util.List;

import com.app.pojos.Services;

public interface IservicesDao 
{
 List<Services>listOfServices();
 Services selectservice(int serviceId);
}
