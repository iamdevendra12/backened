package com.app.dao;

import java.util.List;

import com.app.pojos.Address;
import com.app.pojos.ServiceProvider;
import com.app.pojos.ServiceProviderHelper;
import com.app.pojos.User;

public interface ISpDao {
	List<ServiceProvider>allsp();
	List<User>listofsp();
	List<ServiceProvider>listofavailablesp(int serviceId);
	ServiceProviderHelper registerSp(ServiceProviderHelper s);
	Address updateAddress(Address a,int addressId);
	ServiceProvider getspById(int spId);
	ServiceProvider getserviceProvider(int serviceProviderId);
	ServiceProvider getStatus(int serviceProviderId);
	ServiceProvider updateSpstatus(ServiceProvider s);
	ServiceProvider updateSpstatusavailable(ServiceProvider s,int serviceProviderId);
	//void deleteUser(User u);
	void deletesp(int spId);
	ServiceProvider getSpByUser(User user);
	void changeStatus(ServiceProvider sp);
	
}
