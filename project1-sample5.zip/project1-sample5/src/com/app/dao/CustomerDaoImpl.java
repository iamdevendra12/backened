package com.app.dao;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.app.pojos.Address;
import com.app.pojos.Orders;
import com.app.pojos.ServiceProvider;
import com.app.pojos.User;
import com.app.pojos.UserHelper;
import com.app.pojos.UserRole;
@Repository
@Transactional
public class CustomerDaoImpl implements ICustomerDao {
  @Autowired
  private SessionFactory sf;
	
	@Override
	public UserHelper registerNewMember(UserHelper u) 
	{
		User user = new User(u.getUserName(), u.getEmail(), u.getPassword(), UserRole.valueOf("CUSTOMER"));
		Address address = new Address(u.getFlatNo(), u.getPinCode(), u.getHouseName(), u.getApartmentName(), u.getArea(), u.getCity(), u.getState(), u.getCountry(), u.getCellNo());
		user.addAddress(address);
		 sf.getCurrentSession().persist(user); 
		 return u;
	}

	@Override
	public User updateUser(UserHelper uh,int userId) {
		
		User user=sf.getCurrentSession().get(User.class,userId);
		user.setEmail(uh.getEmail());
		user.setPassword(uh.getPassword());
		user.setUserName(uh.getUserName());
		user.setRole(uh.getRole());
		Address address = user.getAddress();
		address.setApartmentName(uh.getApartmentName());
		address.setArea(uh.getArea());
		address.setCellNo(uh.getCellNo());
		address.setCity(uh.getCity());
		address.setCountry(uh.getCountry());
		address.setFlatNo(uh.getFlatNo());
		address.setHouseName(uh.getHouseName());
		address.setPinCode(uh.getPinCode());
		address.setState(uh.getState());
		System.out.println(address);
		user.setAddress(address);
		//System.out.println("id"+id);
		 sf.getCurrentSession().update(user);
		return user;
		
	}

	@Override
	public Address updateAddress(Address a, int addressId) {
	Address ad=sf.getCurrentSession().get(Address.class, addressId);
	ad.setFlatNo(a.getFlatNo());
	ad.setHouseName(a.getHouseName());
	ad.setApartmentName(a.getApartmentName());
	ad.setArea(a.getArea());
	ad.setCity(a.getCity());
	ad.setCountry(a.getCountry());
	ad.setPinCode(a.getPinCode());
	ad.setCellNo(a.getCellNo());
	sf.getCurrentSession().update(ad);
		return ad;
	}

	@Override
	public User getUserByEmail(String userEmail) 
	{
		String jpql = "select u from User u where u.email=:em";
		return sf.getCurrentSession().createQuery(jpql, User.class).setParameter("em", userEmail).getSingleResult();
	}

	@Override
	public ServiceProvider getSPById(int spId) 
	{
		return sf.getCurrentSession().get(ServiceProvider.class, spId);
	}

	@Override
	public String addOrder(User user, Orders o, ServiceProvider sp) 
	{
		sp.addOrders(o);
		user.addOrders(o);
		sf.getCurrentSession().update(sp);
		sf.getCurrentSession().update(user);
		return "Order added";
	}
}
