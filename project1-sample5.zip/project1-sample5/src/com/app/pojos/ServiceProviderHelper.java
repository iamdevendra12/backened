package com.app.pojos;

public class ServiceProviderHelper 
{

	private Integer userId;
	private String userName,email,password;
	private UserRole role;
	private int flatNo,pinCode;
	private String houseName,apartmentName,area,city,state,country,cellNo;
	private String service;
   public ServiceProviderHelper() {
	// TODO Auto-generated constructor stub
}
public ServiceProviderHelper(String userName, String email, String password, UserRole role, int flatNo, int pinCode,
		String houseName, String apartmentName, String area, String city, String state, String country, String cellNo,
		String service) {
	super();
	this.userName = userName;
	this.email = email;
	this.password = password;
	this.role = role;
	this.flatNo = flatNo;
	this.pinCode = pinCode;
	this.houseName = houseName;
	this.apartmentName = apartmentName;
	this.area = area;
	this.city = city;
	this.state = state;
	this.country = country;
	this.cellNo = cellNo;
	this.service = service;
}
public Integer getUserId() {
	return userId;
}
public void setUserId(Integer userId) {
	this.userId = userId;
}
public String getUserName() {
	return userName;
}
public void setUserName(String userName) {
	this.userName = userName;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}
public UserRole getRole() {
	return role;
}
public void setRole(UserRole role) {
	this.role = role;
}
public int getFlatNo() {
	return flatNo;
}
public void setFlatNo(int flatNo) {
	this.flatNo = flatNo;
}
public int getPinCode() {
	return pinCode;
}
public void setPinCode(int pinCode) {
	this.pinCode = pinCode;
}
public String getHouseName() {
	return houseName;
}
public void setHouseName(String houseName) {
	this.houseName = houseName;
}
public String getApartmentName() {
	return apartmentName;
}
public void setApartmentName(String apartmentName) {
	this.apartmentName = apartmentName;
}
public String getArea() {
	return area;
}
public void setArea(String area) {
	this.area = area;
}
public String getCity() {
	return city;
}
public void setCity(String city) {
	this.city = city;
}
public String getState() {
	return state;
}
public void setState(String state) {
	this.state = state;
}
public String getCountry() {
	return country;
}
public void setCountry(String country) {
	this.country = country;
}
public String getCellNo() {
	return cellNo;
}
public void setCellNo(String cellNo) {
	this.cellNo = cellNo;
}
public String getService() {
	return service;
}
public void setService(String service) {
	this.service = service;
}
@Override
public String toString() {
	return "ServiceProviderHelper [userId=" + userId + ", userName=" + userName + ", email=" + email + ", password="
			+ password + ", role=" + role + ", flatNo=" + flatNo + ", pinCode=" + pinCode + ", houseName=" + houseName
			+ ", apartmentName=" + apartmentName + ", area=" + area + ", city=" + city + ", state=" + state
			+ ", country=" + country + ", cellNo=" + cellNo + ", service=" + service + "]";
}
   
}
