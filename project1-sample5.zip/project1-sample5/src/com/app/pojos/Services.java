package com.app.pojos;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.*;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
public class Services 
{
	private Integer serviceId;
	private String serviceName;
	private List<ServiceProvider>sp=new ArrayList<>();
	
	public Services() {
		// TODO Auto-generated constructor stub
	}
	public Services(String serviceName) {
		super();
		this.serviceName = serviceName;
	}
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public Integer getServiceId() {
		return serviceId;
	}
	public void setServiceId(Integer serviceId) {
		this.serviceId = serviceId;
	}
	public String getServiceName() {
		return serviceName;
	}
	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}
	@JsonIgnore
	@OneToMany(mappedBy = "service", cascade = CascadeType.ALL, orphanRemoval = true,fetch = FetchType.EAGER)
	
	public List<ServiceProvider> getSp() {
		return sp;
	}
	public void setSp(List<ServiceProvider> sp) {
		this.sp = sp;
	}
	public void addServiceProvider(ServiceProvider sp)
	{
		this.sp.add(sp);
		sp.setService(this);
	}
	public void removeServiceProvider(ServiceProvider sp)
	{
		this.sp.remove(sp);
		sp.setService(null);
	}
	@Override
	public String toString() {
		return "Services [serviceId=" + serviceId + ", serviceName=" + serviceName + "]";
	}
	

}
