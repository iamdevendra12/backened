package com.app.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.dao.IUserDao;
import com.app.pojos.Address;
import com.app.pojos.User;
import com.app.pojos.UserHelper;



@RestController
@CrossOrigin
@RequestMapping("/user")
public class UserController {
@Autowired
private IUserDao dao;

@PostMapping("/login")
public ResponseEntity<?> getUser(@RequestBody User u)
{
	
try {
	User user = dao.validateUser(u.getEmail(), u.getPassword());
	return new ResponseEntity<User>(user,HttpStatus.CREATED);
} catch (Exception e) 
{
	// TODO Auto-generated catch block
	e.printStackTrace();
	return null;
}
}

@DeleteMapping("/{userId}")
public void deleteUser(@PathVariable int userId)
{
	
	dao.deleteUser(userId);
}
@PostMapping("/getUserByEmail")
public ResponseEntity<?> getUserByEmail(@RequestBody String email)
{
	User user = dao.getUserByEmail(email);
	Address address = user.getAddress();
	UserHelper uh = new UserHelper(user.getUserName(), user.getEmail(), user.getPassword(), user.getRole(), address.getFlatNo(), address.getPinCode(), address.getHouseName(), address.getApartmentName(), address.getArea(), address.getCity(), address.getState(), address.getCountry(), address.getCellNo());
	uh.setUserId(user.getUserId());
	return new ResponseEntity<UserHelper>(uh, HttpStatus.OK);
}
}
