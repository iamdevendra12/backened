package com.app.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.dao.ICustomerDao;
import com.app.dao.ISpDao;
import com.app.pojos.Address;
import com.app.pojos.ServiceProvider;
import com.app.pojos.ServiceProviderHelper;
import com.app.pojos.Services;
import com.app.pojos.User;
import com.app.pojos.UserHelper;

@RestController
@CrossOrigin
@RequestMapping("/serviceprovider")
public class SpController 
{
	@Autowired
	private ISpDao dao;
	@Autowired
	private ICustomerDao dao1;
	@GetMapping("/listsp")
	public ResponseEntity<?>allSp()
	{
		List<ServiceProvider>allsp=dao.allsp();
		if (allsp.size() == 0)
			return new ResponseEntity<Void>(HttpStatus.NO_CONTENT);
		return new ResponseEntity<List<ServiceProvider>>(allsp, HttpStatus.OK);
		
	}
	
	@GetMapping("/list")
	public ResponseEntity<?>getallSp()
	{
		List<User>allsp=dao.listofsp();
		if (allsp.size() == 0)
			return new ResponseEntity<Void>(HttpStatus.NO_CONTENT);
		return new ResponseEntity<List<User>>(allsp, HttpStatus.OK);
		
	}
	
	@GetMapping("/{serviceId}")
	public ResponseEntity<?> listOfAvServiceprovider(@PathVariable int serviceId) {
		System.out.println("in list sp");
		List<ServiceProvider> availablesp = dao.listofavailablesp(serviceId);
		if (availablesp.size() == 0)
			return new ResponseEntity<Void>(HttpStatus.NO_CONTENT);
		return new ResponseEntity<List<ServiceProvider>>(availablesp, HttpStatus.OK);
	}
	@DeleteMapping("/delete/{serviceProviderId}")
	public void deleteUser(@PathVariable int serviceProviderId)
	{
		
		dao.deletesp(serviceProviderId);
	}
	
	
	@PostMapping("/register")
	public ResponseEntity<?>addSp(@RequestBody ServiceProviderHelper u)
	{
		System.out.println(u);
		System.out.println("in registration");
		try
		{
			
			return new ResponseEntity<ServiceProviderHelper>(dao.registerSp(u),HttpStatus.CREATED);
		}catch(RuntimeException e)
		{
			e.printStackTrace();
			return new ResponseEntity<Void>(HttpStatus.INTERNAL_SERVER_ERROR);
		}		
	}
	@PostMapping("/updatespaddress/{addressId}")
	//@RequestMapping(value = {"/updateuser/{userId}"},method = RequestMethod.POST)
	public ResponseEntity<?>updateAddress(@RequestBody Address u,@PathVariable int addressId)
	{
		System.out.println("in update");
		System.out.println("id "+addressId);
		try
		{
			
			return new ResponseEntity<Address>(dao.updateAddress(u, addressId),HttpStatus.CREATED);
		}catch(RuntimeException e)
		{
			e.printStackTrace();
			return new ResponseEntity<Void>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
		
	}
	@GetMapping("/sp/{serviceProviderId}")
	private ResponseEntity<?>getSp(@PathVariable int serviceProviderId)
	{
		ServiceProvider sp=dao.getserviceProvider(serviceProviderId);
		dao.changeStatus(sp);
		return new ResponseEntity<ServiceProvider>(sp,HttpStatus.OK);
	}
	
	@GetMapping("/updatestatus/{serviceProviderId}")
	private ResponseEntity<?>setStatus(@PathVariable int serviceProviderId)
	{
		try
		{
			ServiceProvider sp = dao.getserviceProvider(serviceProviderId);
			dao.updateSpstatus(sp);
			return new ResponseEntity<String>("Status updated", HttpStatus.OK);
		}catch(RuntimeException e)
		{
			e.printStackTrace();
			return new ResponseEntity<String>("Failed", HttpStatus.OK);
		}
	}
	@PostMapping("/sp/updatestatusav/{serviceProviderId}")
	private ResponseEntity<?>setStatusavailable(@RequestBody ServiceProvider s,@PathVariable int serviceProviderId)
	{
		try
		{
			
			return new ResponseEntity<ServiceProvider>(dao.updateSpstatusavailable(s, serviceProviderId),HttpStatus.CREATED);
		}catch(RuntimeException e)
		{
			e.printStackTrace();
			return new ResponseEntity<Void>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
		
	}
	@GetMapping("/status/{serviceProviderId}")
	private ResponseEntity<ServiceProvider>getStatus(@PathVariable int serviceProviderId)
	{
			return new ResponseEntity<ServiceProvider>(dao.getStatus(serviceProviderId),HttpStatus.CREATED);
	}
	@PostMapping("/getspByEmail")
	public ResponseEntity<?> getspByEmail(@RequestBody String userEmail)
	{
		User user = dao1.getUserByEmail(userEmail);
		ServiceProvider sp = dao.getSpByUser(user);
		return new ResponseEntity<ServiceProvider>(sp, HttpStatus.OK);
	}
}

