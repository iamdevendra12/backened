package com.app.controller;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.app.dao.ICustomerDao;
import com.app.pojos.Address;
import com.app.pojos.Email;
import com.app.pojos.Orders;
import com.app.pojos.ServiceProvider;
import com.app.pojos.Services;
import com.app.pojos.User;
import com.app.pojos.UserHelper;
import com.fasterxml.jackson.annotation.JacksonInject.Value;

@RestController
@CrossOrigin
@RequestMapping("/customer")
public class CustomerController 
{
	@Autowired
	private ICustomerDao dao;
	@Autowired
	private JavaMailSender sender;
	//@RequestMapping(value = {"/new/{userId}"},method = RequestMethod.POST)
//	public ResponseEntity<?>addUser(@RequestBody User u,@PathVariable Integer userId)
//	{
//		System.out.println("in registration");
//		try
//		{ 
//			
//			return new ResponseEntity<User>(dao.registerNewMember(u),HttpStatus.CREATED);
//		}catch(RuntimeException e)
//		{
//			e.printStackTrace();
//			return new ResponseEntity<Void>(HttpStatus.INTERNAL_SERVER_ERROR);
//		}
//		
//		
//	}
//	

	@PostMapping("/register")
	public ResponseEntity<?>addUser(@RequestBody UserHelper u)
	{
		System.out.println(u);
		System.out.println("in registration");
		try
		{
			
			return new ResponseEntity<UserHelper>(dao.registerNewMember(u),HttpStatus.CREATED);
		}catch(RuntimeException e)
		{
			e.printStackTrace();
			return new ResponseEntity<Void>(HttpStatus.INTERNAL_SERVER_ERROR);
		}		
	}
	@PostMapping("/updateuser/{userId}")
	//@RequestMapping(value = {"/updateuser/{userId}"},method = RequestMethod.POST)
	public ResponseEntity<?>UpdateUser(@RequestBody UserHelper u,@PathVariable int userId)
	{
		System.out.println("in update");
		System.out.println("id "+userId);
		try
		{
			
			return new ResponseEntity<User>(dao.updateUser(u,userId),HttpStatus.CREATED);
		}catch(RuntimeException e)
		{
			e.printStackTrace();
			return new ResponseEntity<Void>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
		
	}
	@PostMapping("/updateaddress/{addressId}")
	//@RequestMapping(value = {"/updateuser/{userId}"},method = RequestMethod.POST)
	public ResponseEntity<?>updateAddress(@RequestBody Address u,@PathVariable int addressId)
	{
		System.out.println("in update");
		System.out.println("id "+addressId);
		try
		{
			
			return new ResponseEntity<Address>(dao.updateAddress(u, addressId),HttpStatus.CREATED);
		}catch(RuntimeException e)
		{
			e.printStackTrace();
			return new ResponseEntity<Void>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
		
	}
	
	@PostMapping("/sendMail")
	public ResponseEntity<?> sendMail(@RequestBody Email em)
	{
		System.out.println(em.getDestEmail()+" "+em.getMessage());
		SimpleMailMessage msg = new SimpleMailMessage();
		msg.setTo(em.getDestEmail());
		msg.setSubject(em.getSubject());
		msg.setText(em.getMessage());
		sender.send(msg);
		return new ResponseEntity<String>("Email sent", HttpStatus.OK);
	}
	@PostMapping("/addOrder/{spId}")
	public ResponseEntity<?> addOrder(@RequestBody String userEmail,@PathVariable int spId)
	{
		User user = dao.getUserByEmail(userEmail);
		ServiceProvider sp = dao.getSPById(spId);
		double amount = 0;
		Services service = sp.getService();
		if(service.getServiceName().equals("Plumber"))
			amount = 150;
		else
			amount = 100;
		Orders o = new Orders(new Date(), amount); 
		String string = dao.addOrder(user,o,sp);
		return new ResponseEntity<String>(string, HttpStatus.OK);
	}
	@PostMapping("/getOrders")
	public ResponseEntity<?> getOrders(@RequestBody String userEmail)
	{
		User user = dao.getUserByEmail(userEmail);
		List<Orders> orders = user.getOrders();
		return new ResponseEntity<List<Orders>>(orders, HttpStatus.OK);
	}
}
